"""Hello-world
"""

from hello.world import MSG
