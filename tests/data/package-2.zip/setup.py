"""Setup and install package-1

Typical usage:
  python setup.py develop
  python setup.py install
"""

import setuptools


def setup():
  setuptools.setup(
      name="hello-world",
      use_witch_ver={"custom_str_func": "str_func_pep440"},
      packages=setuptools.find_packages(exclude=["tests", "tests.*"]))


if __name__ == "__main__":
  setup()
