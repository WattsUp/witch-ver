# Hello-world module is missing PEP0257 docstring

from hello.world import MSG
