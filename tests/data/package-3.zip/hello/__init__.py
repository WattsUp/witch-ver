"""Hello-world
"""

from hello.version import __version__

from hello.world import MSG
