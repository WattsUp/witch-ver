"""Contains text
"""

MSG = "Howdy"
