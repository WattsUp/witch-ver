"""Module version information
"""

__all__ = ["__version__", "version_dict"]

version_dict = {
    "tag": "v0.0.0",
    "tag_prefix": "v",
    "sha": "6f14ed6dadf0327ea2ee869bcc275118e71f300a",
    "sha_abbrev": "6f14ed6",
    "branch": "master",
    "date": "2022-07-29T14:15:31-07:00",
    "dirty": False,
    "distance": 3,
    "pretty_str": "0.0.0+3.6f14ed6dadf0327ea2ee869bcc275118e71f300a",
    "git_dir": None
}

_semver = None


def _get_version() -> dict:
  """Get latest version

  Returns:
    Git object
  """
  global _semver
  if _semver is not None:
    return _semver
  try:
    import witch_ver  # pylint: disable=import-outside-toplevel
  except ImportError:
    _semver = version_dict
    return version_dict

  try:
    import re  # pylint: disable=import-outside-toplevel

    # yapf: disable since witch_ver overwrites without rerunning formatter
    def str_func(g: witch_ver.GitVer) -> str:
      return f"{g.core}+{g.distance}.{g.sha}"

    config = {
        "custom_str_func": str_func,
        "path": ".",
        "distance": 10
    }
    # yapf: enable

    g = witch_ver.fetch(**config, cache=version_dict)
    _semver = g.asdict(isoformat_date=True)

    # Overwrite this file with new version info
    new_file = "version_dict = {\n"
    items = []
    for k, v in _semver.items():
      if isinstance(v, str):
        items.append(f'    "{k}": "{v}"')
      else:
        items.append(f'    "{k}": {v}')
    new_file += ",\n".join(items)
    new_file += "\n}"
    with open(__file__, "r", encoding="utf-8") as file:
      buf = file.read()
      orig = re.search(r"version_dict = {.*?}", buf, flags=re.S)
      if orig[0] == new_file:
        return version_dict
      # Modifications will occur, write (avoids over touching for systems that
      # care about modification date)
      buf = buf[:orig.start()] + new_file + buf[orig.end():]

    with open(__file__, "w", encoding="utf-8") as file:
      file.write(buf)
    return _semver
  except RuntimeError:
    _semver = version_dict
    return version_dict


version_dict = _get_version()

__version__ = version_dict.get("pretty_str")
